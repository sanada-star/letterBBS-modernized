function popup(url) {
	window.open(url, "notice", "width=600,height=450,scrollbars=1");
}
function face(smile) {
    bbscom = document.bbsform.comment.value;
    document.bbsform.comment.value = bbscom + smile;
}
